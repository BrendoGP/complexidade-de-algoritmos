package br.edu.ifba.lojas;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import br.edu.ifba.lojas.contador.Contador;
import br.edu.ifba.lojas.impl.ContadorImpl;
import br.edu.ifba.lojas.impl.Loja;
import br.edu.ifba.lojas.impl.OperacoesImpl;
import br.edu.ifba.lojas.impl.Produtos;
import br.edu.ifba.lojas.operacoes.Operacoes;

/*
 * a classe App possui complexidade linear, O(N) porque possui um loop for que itera 
 * sobre o número total de lojas (Total_De_Lojas). O tempo de execução do loop que é a parte mais
 * significativa do código, aumenta de forma linear de acordo com o número de lojas portanto,
 *  a complexidade é O(Total_De_Lojas).
 * consequências:
 * Essa complexidade limita a escalabilidade do programa. Se o programa precisar lidar com 
 * uma grande quantidade de lojas, pode atingir um ponto em que a execução se torna muito lenta
 * ou até mesmo inviável devido ao aumento no tempo de processamento.
 */

public class App {

    private static final int Total_De_Lojas = 10;
    private static final int Total_De_Contagens= 1000;

    public static void main(String[] args) throws Exception {
        System.out.println("Avaliação I Complexidade de Algoritmos");

        Operacoes<Loja, Produtos> operacoes = new OperacoesImpl();
        Contador<Produtos> contador = new ContadorImpl();
        Map<Loja, List<Produtos>> contagemPorLoja = new TreeMap<>();

        for (int i = 0; i < Total_De_Lojas; i++) {
            int id = (i + 1);
            contagemPorLoja.put(new Loja(id, "Loja CNPJ:00.000.000/0000-" + id), 
                contador.gerarContagem(Total_De_Contagens)
            );
        }

        /* Para realizar os testes basta descomentar os codigos
           (excluir as barras de comentário do teste que queira realizar "//" ).   */

        /*  testando d.1
            imprime as lojas  e sua identificação */
        // operacoes.imprimir(new ArrayList<Loja>(contagemPorLoja.keySet())); 

        /*  testando d.2
            imprime a loja e a quantidade de produtos no estoque em cada loja por contagem */
        //operacoes.imprimir(contagemPorLoja);  
        
        /*  testando d.3
            imprime  a loja e a quantidade de produtos de forma ordenada no estoque
            em cada loja por contagem */
        // Map<Loja, List<Produtos>> contagensOrdenadas = operacoes.ordenar(contagemPorLoja);
        // operacoes.imprimir(contagensOrdenadas);

        /*  testandno d.4
            imprime a soma do total de produtos em todos os estoques de todas as lojas */
        // long totalGeral =  operacoes.total_Geral(contagemPorLoja);
        // System.out.println("A quantidade geral é de: " + totalGeral + " produtos.");

    }//main
}//class
//Brendo Gomes Prates
/*     "Existem apenas 10 tipos de pessoas no mundo:
                 aquelas que entendem binário e aquelas que não entendem."      */   