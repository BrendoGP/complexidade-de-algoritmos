package br.edu.ifba.lojas.impl;

/**
 * classe para simular onde sera feita a contagem(no caso o estoque de Lojas),
 * cuja complexidade, de forma geral, eh constante, O(1).
 * Essas operações executam um número fixo de operações independentemente do 
 * tamanho dos dados de entrada.Portanto, a complexidade é considerada
 * constante para cada um desses métodos.
 * consequências:
 * por ser de complexidade constante o tempo e o espaço necessários para executar o 
 * algoritmo são fixos, independentemente do tamanho da entrada de dados.
 * a classe em geral é eficiente e não apresenta problemas significativos de desempenho 
 * ou uso de memória mesmo para uma entrada de dados muito grande.
 * Vale apena lembrar que método "compareTo" contribui para a eficiência em 
 * operações de comparação e ordenação.
 */

public class Loja implements Comparable<Loja> {

    // Variáveis

    private int id;
    private String cnpj;

    // Bob

    public Loja(int id, String cnpj) {
        this.id = id;
        this.cnpj = cnpj;
    }

    // getters e setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    // Comparador (para possibilitar ordenar) 

    @Override
    public int compareTo(Loja outraLoja) {
        return this.getId() - outraLoja.getId();
    }

    // impressão

    @Override
    public String toString() {
        return "CNPJ: " + cnpj + ", ID: " + id;
    }

}// class

// Brendo Gomes Prates
// Github:brendogp