package br.edu.ifba.lojas.impl;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import br.edu.ifba.lojas.operacoes.Operacoes;
import br.edu.ifba.lojas.ordenador.Ordenador;

// Esta classe é composta por varios métodos de complexidades distintas

public class OperacoesImpl implements Operacoes<Loja,Produtos> {

    /**
     * imprime os dados das lojas
     * 
     * este método (d.1) possui complexidade linear, O(N)
     * É complexidade linear, porque o total de passos de execução
     * cresce linearmente em relação ao tamanho da entrada de dados (total de Lojas). 
     */

    // d.1
    @Override
    public void imprimir(List<Loja> Verificados) {
        for (Loja filial: Verificados) {
            System.out.println(filial);
        };
    }

     /*
      * imprime o estoque(contagem de produtos) por cada loja
      * 
      * esse método tem a complexidade quadratica, O(N^2)
      * tem uma complexidade quadrática, pois envolve dois loops aninhados. Um para iterar sobre 
      * as chaves do Map (O(M)) e outro para iterar sobre as listas de produtos (O(P)). 
      * A multiplicação dessas complexidades resulta em uma complexidade total de O(M * P).
      * consequências:
      * ela implica um aumento exponencial, em grandes conjuntos de dados, a execução do método
      * pode se tornar muito lenta e ineficiente, afetando o desempenho global do programa.
      */

    // d.2
    @Override
    public void imprimir(Map<Loja, List<Produtos>> contagens) {
        for (Loja filial: contagens.keySet()) {
            System.out.println("Contagem do estoque Loja/CNPJ: " + filial.getCnpj());
            for (Produtos contagem: contagens.get(filial)) {
                System.out.println(contagem);
            }
        }
    }

    /*
     *  Ordena as contagens de produtos do estoque por cada loja.
     * 
     *  A complexidade deste metodo eh, N^2LOGN
     *  Mesmo ela apresentando apenas um loop for, este loop faz uma chamada do algoritmo de ordenação
     *  que tem complexidade O(log n).
     *  consequências:
     *  O desempenho do algoritmo será ineficiente, especialmente à medida que o tamanho da entrada (N)
     *  aumenta. Para grandes valores de N, o tempo de execução pode se tornar proibitivamente alto.
     *  E devido a sua complexidade torna o algoritmo mais difíceis de manter, entender e modificar. 
     */

    // d.3
    @Override
     public Map<Loja, List<Produtos>> ordenar(Map<Loja, List<Produtos>> contagens) {
        Map<Loja, List<Produtos>> contagensOrdenadas = new TreeMap<>();

        for (Loja filial: contagens.keySet()) {
            System.out.println("Ordenando as contagens da Loja/CNPJ: " + filial.getCnpj());

            List<Produtos> contagensParaOrdenar = contagens.get(filial);
            Ordenador<Produtos> ordenador = new OrdenadorImpl(contagensParaOrdenar);
            ordenador.ordenar();

            contagensOrdenadas.put(filial, contagensParaOrdenar);
        }

        return contagensOrdenadas;
    }

    /*
     * imprime a soma total de produtos de todos os estoques de cada loja
     * 
     * esse método tem a complexidade cúbica, O(N^3)
     * A complexidade é cúbica porque esse algoritmo tem três camadas de loops aninhados.
     * consequências:
     * A complexidade cúbica indica que o algoritmo é ineficiente para grandes volumes de dados
     * e pode consumir muitos recursos.
     */

    // d.4
    @Override
    public long total_Geral(Map<Loja, List<Produtos>> contagem) {
        long totalGeral = 0;
    
        // Itera sobre as entradas do mapa (lojas e listas de produtos)
        for (Map.Entry<Loja, List<Produtos>> entry : contagem.entrySet()) {
            List<Produtos> produtosList = entry.getValue();
    
            // Itera sobre a lista de produtos da loja
            for (Produtos produto : produtosList) {
                
                // Itera para cada produto, considerando sua quantidade
                for (int i = 0; i < produto.getQuantidade(); i++) {
                    totalGeral++;
                }
            }
        }
    
        return totalGeral;
    }
    
}//class
