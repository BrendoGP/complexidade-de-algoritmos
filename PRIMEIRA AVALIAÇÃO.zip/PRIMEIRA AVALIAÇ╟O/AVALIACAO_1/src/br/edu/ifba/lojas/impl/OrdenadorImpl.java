package br.edu.ifba.lojas.impl;

import java.util.ArrayList;
import java.util.List;

import br.edu.ifba.lojas.ordenador.Ordenador;

/*
 * Classe para auxiliar na ordenação.
 * Esse algoritmo teve como base um algoritmo de "Mergesort" bastante utilizado
 * que se encontra no link abaixo:
 * https://www.delftstack.com/howto/java/merge-sort-arraylist-java/
 * 
 * A complexidade dessa classe é Logarítmica, O(log n)
 * por ser um algoritimo "Mergesort" implementado nesta classe a complexidade é determinada
 * pela complexidade do método ordenar(int inicio, int fim) que é O(log n),onde n é o número total
 * de produtos a serem ordenados. A ordenação ocorre através de divisões recursivas e fusão de
 * subconjuntos ordenados. O algoritmo divide a lista pela metade, ordena cada metade e depois
 * funde as partes ordenadas.
 * consequências:
 * Embora o "Merge Sort" seja eficiente para grandes volumes de dados, ele pode não ser a melhor escolha
 * para conjuntos de dados pequenos devido a alguma sobrecarga adicional devido à recursividade 
 * e às cópias de listas.
 */

public class OrdenadorImpl extends Ordenador<Produtos> {
    

    //Bob
    public OrdenadorImpl(List<Produtos> contagem) {
        super(contagem);
    }

    public void ordenar() {
        ordenar(0, contagem.size() - 1); 
    }

    public void ordenar(int inicio, int fim) {
        if (inicio < fim && (fim - inicio) >= 1) {
            int meio = (fim + inicio) / 2;

            ordenar(inicio, meio);
            ordenar(meio + 1, fim);

            ordenar(inicio, meio, fim);
        }
    }

    private void ordenar(int inicio, int meio, int fim) {
        List<Produtos> contagemTemp = new ArrayList<>();

        int esquerda = inicio;
        int direita = meio + 1;

        while (esquerda <= meio && direita <= fim) {
            if (contagem.get(esquerda).getQuantidade() <= contagem.get(direita).getQuantidade()) {
                contagemTemp.add(contagem.get(esquerda));
                esquerda++;
            } else {
                contagemTemp.add(contagem.get(direita));
                direita++;
            }
        }

        while (esquerda <= meio) {
            contagemTemp.add(contagem.get(esquerda));
            esquerda++;
        }

        while (direita <= fim) {
            contagemTemp.add(contagem.get(direita));
            direita++;
        }

        for (int i = 0; i < contagemTemp.size(); inicio++) {
            contagem.set(inicio, contagemTemp.get(i++));
        }
    }

}//class
