package br.edu.ifba.lojas.operacoes;

import java.util.List;
import java.util.Map;

/*
 * Interface que servira de base para criação das operacoes( d.1,d.2,d.3,d.4).
 * Sua complexidade não pode ser especificada apenas com base na
 * estrutura da interface. A complexidade real dependerá da
 * implementação dos métodos na classe que a implementar.
 */

public interface Operacoes<Verificado, Contador> {

    // d.1
    public void imprimir(List<Verificado> Verificados);

    // d.2
    public void imprimir(Map<Verificado, List<Contador>>m);

    // d.3
    public Map<Verificado, List<Contador>> ordenar(Map<Verificado, List<Contador>>m);

    // d.4
    public long total_Geral(Map<Verificado, List<Contador>> contagem);
    
}
