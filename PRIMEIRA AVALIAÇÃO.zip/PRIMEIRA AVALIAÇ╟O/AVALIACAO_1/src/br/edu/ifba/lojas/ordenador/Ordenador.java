package br.edu.ifba.lojas.ordenador;
import java.util.List;

/**
 * classe que determina as funcionalidades do ordenador, 
 * cuja complexidade, de forma geral, eh constante, O(1)
 * classe responsavel pela ordenação, assim como as outras classes de complexidade constante
 * ela não apresenta problemas significativos no desempenho por causa de entrada de dados muito grande
 * mais lembrando que A complexidade dos seus métodos dependerá da sua implementação  nas classes
 *  que a implementarem.
 */

public abstract class Ordenador<Contador> {
    
 protected List<Contador> contagem = null;

 // Bob

    public Ordenador(List<Contador> contagem) {
        this.contagem = contagem;
    }


// get

    public List<Contador> getcontagem() {
        return this.contagem;
    }

// metodo para ordenagem

    public abstract void ordenar();

}//class
