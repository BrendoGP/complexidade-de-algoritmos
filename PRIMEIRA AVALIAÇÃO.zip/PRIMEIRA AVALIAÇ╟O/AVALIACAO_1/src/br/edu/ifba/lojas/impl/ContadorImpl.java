package br.edu.ifba.lojas.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import br.edu.ifba.lojas.contador.Contador;

/*
 * A classe ContadorImpl possui complexidade linear, O(N)
 * É uma complexidade linear, pois o tempo de execução aumenta de forma proporcional
 * ao número de produtos a serem gerados. Essa complexidade se da por conta de um loop for.
 * Dentro desse loop, temos algumas operações que são de complexidade constante
 * (operações aritméticas simples, chamadas a métodos nextInt e criação de objetos Produtos),
 * e por serem constantes não alteram a complexidade geral.
 * consequências:
 * por ser de complexidade linear sofre ao lidar com grandes volumes de dados, que consequentimente
 * almenta o tempo de processamento deixando a execulção muito mais lenta ou inviável.
 */
public class ContadorImpl implements Contador<Produtos>{

 private static final int qntd_Media = 1000;
 private static final int qntd_Reposicao= 500;

    @Override
    public List<Produtos> gerarContagem(int totalProdutos) {
        List<Produtos> cont_Estoque = new ArrayList<>();
        Random randomizador = new Random();
        for (int i = 0; i < totalProdutos; i++) {
           int porcentagem_Retirada = randomizador.nextInt(50); // o estoque tem baixas de até 50% dos produtos.
           int qntd_mais_reposicao = qntd_Media + randomizador.nextInt(qntd_Reposicao); // alem da quantidade padrão sempre a reposições a cada contagem
           int qntd_Produto_Final = qntd_mais_reposicao;

           if(porcentagem_Retirada != 0){
            int qntd_Porcentagaem_Retirada =  qntd_mais_reposicao * porcentagem_Retirada / 100;
            qntd_Produto_Final -= qntd_Porcentagaem_Retirada;
           }

            Produtos cont_produto = new Produtos(i + 1, qntd_Produto_Final);
            cont_Estoque.add(cont_produto);
    }
    return cont_Estoque;
    }
    
}//class
