package br.edu.ifba.lojas.contador;

import java.util.List;

/*
 * Interface que servira de base para criação do contador( classe que fara a contagem dos produtos
 * do estoque das lojas). Sua complexidade não pode ser especificada apenas com base na
 * estrutura da interface. A complexidade real dependerá da
 * implementação do método "gerarContagem" na classe que a implementar.
 */
public interface Contador<Produtos> {
    
    public List<Produtos> gerarContagem(int totalProdutos);
    
}//class
