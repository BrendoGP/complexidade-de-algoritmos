package br.edu.ifba.lojas.impl;

/**
 * classe para simular o que sera contado(no caso a quantidade dos produtos nos estoques),
 * cuja complexidade, de forma geral, eh constante, O(1).
 * O tempo e o espaço necessários para executar suas operações são fixos e
 * não dependem do tamanho dos dados.Portanto, a complexidade é considerada constante. 
 * consequências:
 * Limitada: a classe é bastante básica e tem uma funcionalidade limitada,
 * focada apenas na representação de um produto em termos de ID e quantidade.
 * Se for necessário adicionar mais funcionalidades no futuro, pode ser necessário 
 * fazer alterações significativas na classe ou criar classes complementares.
 * Simplicidade: A simplicidade da classe pode facilitar a manutenção e extensão no futuro.
 * É mais fácil compreender, modificar e estender essa classe por conta de sua simplicidade.
 */

public class Produtos {

    // variáveis

    private int id;
    private int quantidade;

    // Bob

    public Produtos(int id, int quantidade) {
        this.id = id;
        this.quantidade = quantidade;
    }

    // getters e setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    // impressão

    @Override
    public String toString() {
        return "Quantidade: " + quantidade;
    }

}// class

// Brendo Gomes Prates
